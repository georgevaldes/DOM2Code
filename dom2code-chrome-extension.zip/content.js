// DOM2Code Content Script - Element selection and highlighting

let isSelectionModeActive = false;
let highlightColor = "#4285F4";
let hoveredElement = null;
let highlightOverlay = null;

// Initialize the highlight overlay
function initHighlightOverlay() {
  highlightOverlay = document.createElement('div');
  highlightOverlay.id = 'dom2code-highlight-overlay';
  highlightOverlay.style.position = 'absolute';
  highlightOverlay.style.border = `2px solid ${highlightColor}`;
  highlightOverlay.style.backgroundColor = `${highlightColor}22`;
  highlightOverlay.style.pointerEvents = 'none';
  highlightOverlay.style.zIndex = '999999';
  highlightOverlay.style.display = 'none';
  document.body.appendChild(highlightOverlay);
}

// Update the overlay position to match the target element
function updateOverlay(element) {
  if (!element || !highlightOverlay) return;
  
  const rect = element.getBoundingClientRect();
  highlightOverlay.style.top = `${window.scrollY + rect.top}px`;
  highlightOverlay.style.left = `${window.scrollX + rect.left}px`;
  highlightOverlay.style.width = `${rect.width}px`;
  highlightOverlay.style.height = `${rect.height}px`;
  highlightOverlay.style.display = 'block';
}

// Handle mouse over event
function handleMouseOver(event) {
  if (!isSelectionModeActive) return;
  
  hoveredElement = event.target;
  updateOverlay(hoveredElement);
  
  // Prevent event bubbling
  event.stopPropagation();
}

// Handle mouse out event
function handleMouseOut() {
  if (!isSelectionModeActive) return;
  
  hoveredElement = null;
  if (highlightOverlay) {
    highlightOverlay.style.display = 'none';
  }
}

// Handle click event
function handleClick(event) {
  if (!isSelectionModeActive) return;
  
  // Prevent default action
  event.preventDefault();
  event.stopPropagation();
  
  // Get the element's HTML
  const html = hoveredElement.outerHTML;
  
  // Get metadata
  const metadata = {
    tagName: hoveredElement.tagName.toLowerCase(),
    id: hoveredElement.id,
    classes: Array.from(hoveredElement.classList),
    path: getDomPath(hoveredElement),
    url: window.location.href
  };
  
  // Send to background script
  chrome.runtime.sendMessage({
    command: 'sendHTML',
    html: html,
    metadata: metadata
  }, (response) => {
    if (response && response.success) {
      showNotification('HTML sent to VS Code!');
    } else {
      showNotification('Failed to send HTML. Is VS Code connected?', true);
    }
  });
  
  return false;
}

// Get DOM path for an element
function getDomPath(element) {
  let path = [];
  
  while (element && element.nodeType === Node.ELEMENT_NODE) {
    let selector = element.nodeName.toLowerCase();
    if (element.id) {
      selector += `#${element.id}`;
      path.unshift(selector);
      break;
    } else {
      let sibling = element;
      let siblingIndex = 1;
      
      while (sibling = sibling.previousElementSibling) {
        if (sibling.nodeName.toLowerCase() === selector) {
          siblingIndex++;
        }
      }
      
      if (siblingIndex > 1) {
        selector += `:nth-of-type(${siblingIndex})`;
      }
    }
    
    path.unshift(selector);
    element = element.parentNode;
  }
  
  return path.join(' > ');
}

// Show notification
function showNotification(message, isError = false) {
  const notification = document.createElement('div');
  notification.className = 'dom2code-notification';
  notification.textContent = message;
  notification.style.position = 'fixed';
  notification.style.bottom = '20px';
  notification.style.right = '20px';
  notification.style.padding = '10px 15px';
  notification.style.backgroundColor = isError ? '#F44336' : '#4CAF50';
  notification.style.color = 'white';
  notification.style.borderRadius = '4px';
  notification.style.zIndex = '999999';
  notification.style.opacity = '0';
  notification.style.transform = 'translateY(20px)';
  notification.style.transition = 'opacity 0.3s, transform 0.3s';
  
  document.body.appendChild(notification);
  
  // Trigger animation
  setTimeout(() => {
    notification.style.opacity = '1';
    notification.style.transform = 'translateY(0)';
  }, 10);
  
  // Remove after 3 seconds
  setTimeout(() => {
    notification.style.opacity = '0';
    notification.style.transform = 'translateY(20px)';
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 300);
  }, 3000);
}

// Toggle selection mode
function toggleSelectionMode(value) {
  isSelectionModeActive = value;
  
  if (isSelectionModeActive) {
    document.addEventListener('mouseover', handleMouseOver, true);
    document.addEventListener('mouseout', handleMouseOut, true);
    document.addEventListener('click', handleClick, true);
    showNotification('Selection mode enabled. Click on an element to send to VS Code.');
  } else {
    document.removeEventListener('mouseover', handleMouseOver, true);
    document.removeEventListener('mouseout', handleMouseOut, true);
    document.removeEventListener('click', handleClick, true);
    if (highlightOverlay) {
      highlightOverlay.style.display = 'none';
    }
  }
}

// Get element at last right-click point
function getElementAtPoint() {
  if (hoveredElement) {
    const html = hoveredElement.outerHTML;
    
    const metadata = {
      tagName: hoveredElement.tagName.toLowerCase(),
      id: hoveredElement.id,
      classes: Array.from(hoveredElement.classList),
      path: getDomPath(hoveredElement),
      url: window.location.href
    };
    
    chrome.runtime.sendMessage({
      command: 'sendHTML',
      html: html,
      metadata: metadata
    }, (response) => {
      if (response && response.success) {
        showNotification('HTML sent to VS Code!');
      } else {
        showNotification('Failed to send HTML. Is VS Code connected?', true);
      }
    });
  } else {
    showNotification('No element selected. Right-click directly on an element.', true);
  }
}

// Initialize
(function() {
  initHighlightOverlay();
  
  // Check current state
  chrome.runtime.sendMessage({ command: 'getState' }, (response) => {
    if (response && response.isSelectionModeActive) {
      toggleSelectionMode(true);
    }
    
    if (response && response.settings && response.settings.highlightColor) {
      highlightColor = response.settings.highlightColor;
      if (highlightOverlay) {
        highlightOverlay.style.border = `2px solid ${highlightColor}`;
        highlightOverlay.style.backgroundColor = `${highlightColor}22`;
      }
    }
  });
  
  // Listen for messages from background script
  chrome.runtime.onMessage.addListener((message) => {
    if (message.command === 'toggleSelectionMode') {
      toggleSelectionMode(message.value);
    } else if (message.command === 'getElementAtPoint') {
      getElementAtPoint();
    }
  });
  
  // Context menu click handler
  document.addEventListener('contextmenu', (event) => {
    // Store the right-clicked element
    hoveredElement = event.target;
  });
})(); 