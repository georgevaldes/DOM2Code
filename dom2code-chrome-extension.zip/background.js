// Handle extension initialization and communication with VS Code
let vsCodeConnection = null;
let isSelectionModeActive = false;
let serverPort = 54321; // Default port for WebSocket connection

// Initialize connection to VS Code
function initVSCodeConnection() {
  vsCodeConnection = new WebSocket(`ws://localhost:${serverPort}`);
  
  vsCodeConnection.onopen = () => {
    console.log('Connected to VS Code');
    chrome.storage.local.set({ isConnected: true });
    chrome.action.setBadgeText({ text: "ON" });
    chrome.action.setBadgeBackgroundColor({ color: "#4CAF50" });
  };
  
  vsCodeConnection.onclose = () => {
    console.log('Disconnected from VS Code');
    chrome.storage.local.set({ isConnected: false });
    chrome.action.setBadgeText({ text: "OFF" });
    chrome.action.setBadgeBackgroundColor({ color: "#F44336" });
    
    // Try to reconnect after a delay
    setTimeout(initVSCodeConnection, 5000);
  };
  
  vsCodeConnection.onerror = (error) => {
    console.error('WebSocket Error:', error);
  };
  
  vsCodeConnection.onmessage = (event) => {
    const message = JSON.parse(event.data);
    handleVSCodeMessage(message);
  };
}

// Handle messages from VS Code
function handleVSCodeMessage(message) {
  switch (message.command) {
    case 'toggleSelectionMode':
      isSelectionModeActive = message.value;
      broadcastToTabs({ command: 'toggleSelectionMode', value: isSelectionModeActive });
      break;
    case 'updateSettings':
      chrome.storage.local.set({ settings: message.settings });
      break;
  }
}

// Send HTML to VS Code
function sendHTMLToVSCode(html, metadata = {}) {
  if (vsCodeConnection && vsCodeConnection.readyState === WebSocket.OPEN) {
    vsCodeConnection.send(JSON.stringify({
      command: 'injectHTML',
      html: html,
      metadata: metadata
    }));
    return true;
  }
  return false;
}

// Initialize context menu
function initContextMenu() {
  chrome.contextMenus.create({
    id: "selectElement",
    title: "Send to VS Code",
    contexts: ["all"]
  });
}

// Broadcast message to all tabs
function broadcastToTabs(message) {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, message);
    }
  });
}

// Event listeners
chrome.runtime.onInstalled.addListener(() => {
  initContextMenu();
  chrome.storage.local.set({ 
    isConnected: false,
    isSelectionModeActive: false,
    settings: {
      highlightColor: "#4285F4",
      autoFormat: true,
      serverPort: 54321
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.command === 'sendHTML') {
    const success = sendHTMLToVSCode(message.html, message.metadata);
    sendResponse({ success });
  } else if (message.command === 'getState') {
    chrome.storage.local.get(['isConnected', 'isSelectionModeActive', 'settings'], (data) => {
      sendResponse(data);
    });
    return true; // Keep the channel open for async response
  } else if (message.command === 'toggleConnection') {
    if (!vsCodeConnection || vsCodeConnection.readyState !== WebSocket.OPEN) {
      initVSCodeConnection();
    } else {
      vsCodeConnection.close();
    }
    sendResponse({ success: true });
  } else if (message.command === 'updateSettings') {
    chrome.storage.local.set({ settings: message.settings }, () => {
      serverPort = message.settings.serverPort;
      sendResponse({ success: true });
    });
    return true;
  }
});

// Initialize connection on startup
chrome.storage.local.get(['settings'], (data) => {
  if (data.settings && data.settings.serverPort) {
    serverPort = data.settings.serverPort;
  }
  initVSCodeConnection();
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "selectElement") {
    chrome.tabs.sendMessage(tab.id, { command: 'getElementAtPoint' });
  }
}); 