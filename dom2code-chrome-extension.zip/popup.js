// Popup UI Logic
document.addEventListener('DOMContentLoaded', () => {
  const statusIndicator = document.getElementById('status-indicator');
  const statusText = document.getElementById('status-text');
  const toggleConnectionBtn = document.getElementById('toggle-connection');
  const toggleSelectionModeBtn = document.getElementById('toggle-selection-mode');
  const highlightColorInput = document.getElementById('highlight-color');
  const serverPortInput = document.getElementById('server-port');
  const autoFormatCheckbox = document.getElementById('auto-format');
  const saveSettingsBtn = document.getElementById('save-settings');
  
  let isConnected = false;
  let isSelectionModeActive = false;
  
  // Initialize UI
  function updateUI() {
    // Update connection status
    statusIndicator.className = `status-indicator ${isConnected ? 'connected' : 'disconnected'}`;
    statusText.textContent = isConnected ? 'Connected to VS Code' : 'Disconnected from VS Code';
    toggleConnectionBtn.textContent = isConnected ? 'Disconnect' : 'Connect to VS Code';
    
    // Update selection mode button
    toggleSelectionModeBtn.disabled = !isConnected;
    toggleSelectionModeBtn.textContent = isSelectionModeActive ? 'Disable Selection Mode' : 'Enable Selection Mode';
    toggleSelectionModeBtn.className = isSelectionModeActive ? 'toggle-active' : '';
  }
  
  // Load current state
  chrome.runtime.sendMessage({ command: 'getState' }, (data) => {
    if (data) {
      isConnected = data.isConnected;
      isSelectionModeActive = data.isSelectionModeActive;
      
      if (data.settings) {
        highlightColorInput.value = data.settings.highlightColor || '#4285F4';
        serverPortInput.value = data.settings.serverPort || 54321;
        autoFormatCheckbox.checked = data.settings.autoFormat !== false;
      }
      
      updateUI();
    }
  });
  
  // Toggle connection
  toggleConnectionBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ command: 'toggleConnection' }, () => {
      // We'll get the updated state through storage listeners
    });
  });
  
  // Toggle selection mode
  toggleSelectionModeBtn.addEventListener('click', () => {
    isSelectionModeActive = !isSelectionModeActive;
    
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          command: 'toggleSelectionMode',
          value: isSelectionModeActive
        });
      }
    });
    
    // Also update the stored state
    chrome.storage.local.set({ isSelectionModeActive });
    
    updateUI();
  });
  
  // Save settings
  saveSettingsBtn.addEventListener('click', () => {
    const settings = {
      highlightColor: highlightColorInput.value,
      serverPort: parseInt(serverPortInput.value, 10),
      autoFormat: autoFormatCheckbox.checked
    };
    
    chrome.runtime.sendMessage({
      command: 'updateSettings',
      settings: settings
    }, () => {
      saveSettingsBtn.textContent = 'Saved!';
      setTimeout(() => {
        saveSettingsBtn.textContent = 'Save Settings';
      }, 1500);
    });
  });
  
  // Listen for state changes
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.isConnected) {
      isConnected = changes.isConnected.newValue;
      updateUI();
    }
    
    if (changes.isSelectionModeActive) {
      isSelectionModeActive = changes.isSelectionModeActive.newValue;
      updateUI();
    }
  });
}); 